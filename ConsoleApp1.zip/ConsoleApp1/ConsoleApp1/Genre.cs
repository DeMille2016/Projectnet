﻿namespace ConsoleApp1
{
    public enum Genre : byte
    {
        POP = 0,
        ROCK,
        HIP_HOP,
        TECHNO,
        DNB,
        JAZZ,
        DUBSTEP
        
    }
}